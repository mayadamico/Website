module.exports = {
    plugins: {
        autoprefixer: {},
        cssnano: {}
    }
};
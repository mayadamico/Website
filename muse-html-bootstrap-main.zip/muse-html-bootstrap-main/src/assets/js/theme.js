// Vendor Imports
import 'bootstrap';

// Components
import './components/aos';
import './components/modal';
import './components/slideout';
import './components/swiper';

// theme misc js
import './misc';